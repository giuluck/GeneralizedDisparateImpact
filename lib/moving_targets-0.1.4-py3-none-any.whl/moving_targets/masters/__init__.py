"""Interfaces and classes for Moving Targets Masters."""

from moving_targets.masters.master import Master, RegressionMaster, ClassificationMaster
