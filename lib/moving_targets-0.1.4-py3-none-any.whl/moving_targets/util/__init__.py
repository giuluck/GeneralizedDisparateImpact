"""Utilities functions and data types for the entire Moving Targets module."""
